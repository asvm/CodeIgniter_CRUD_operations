<!DOCTYPE html>
<html>
<head>
  <title>User Accounts</title>
  <style>
  table {
      border-collapse: collapse;
      width: 100%;
  }
  th, td {
      text-align: left;
      padding: 8px;
  }
  tr:nth-child(even){background-color: #f2f2f2}
  </style>
</head>

<body>
  <table border="1">
    <tr>
      <th>First_Name</th>
      <th>Last_Name</th>
      <th>Phone_Number</th>
      <th>Address</th>
    </tr>
  <?php foreach($users as $user):  ?>

    <tr>
      <td>
          <?php echo $user->firstname; ?>
      </td>
      <td>
          <?php echo $user->lastname; ?>
      </td>
      <td>
          <?php echo $user->phno; ?>
      </td>
      <td>
          <?php echo $user->address; ?>
      </td>
      <?php endforeach; ?>
    </tr>
  </table>
</body>
</html>

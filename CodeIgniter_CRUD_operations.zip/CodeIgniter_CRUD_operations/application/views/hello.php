<?php

echo "Hi my first program in Codeignitor";

?>

<!DOCTYPE html>
<html>
<head>
  <title>Writing to a Database from Php Form</title>
</head>

<body>
<form action="read" method="POST">
    <input type="text" name="firstname" placeholder="Firstname">
    <br>
    <input type="text" name="lastname" placeholder="Lastname">
    <br>
    <button type="submit">Sign up</button>
</form>
</body>

</html>

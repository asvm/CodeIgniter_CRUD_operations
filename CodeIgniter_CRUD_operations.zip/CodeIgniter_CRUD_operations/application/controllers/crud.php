<?php
class crud extends CI_Controller {

	function index() {
		// loads the View
		$this->load->view('hello');

		// load the Model in the Controller
		$this->load->model('fetch');

		// load the function from the Model
		$this->fetch->model_read(); 
	}
}


?>
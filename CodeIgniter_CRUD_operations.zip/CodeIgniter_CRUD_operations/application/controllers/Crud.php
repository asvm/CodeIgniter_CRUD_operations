<?php
class Crud extends CI_Controller {

	function index() {
	// leads the View
	//$this->load->view('hello');

        // giving a aliase name as 'fb' for authenticate Model 
        $this->load->model('authenticate','fb');

        // using alise name 'fb' to call the Model function
	$data = $this->fb->getData();

	print_r($data); 
	}
}


?>

<?php
//define('BASEPATH') OR exit('No direct script access allowed');

class Blog extends CI_Controller{

    function index() {
        // loading the view
        $this->load->view('blog/index');

        // loading the MongoDeleteBatch
        $this->load->model('read');

        // loading function from the model
        $this->read->form_read();
    }

    // read data from View-Form
    function form_read() {
       print_r($_POST);
    }
}

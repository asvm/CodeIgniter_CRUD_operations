<?php
class Users extends CI_Controller {

   public function index() {
     $this->load->model('usermodel');
     $data['users'] = $this->usermodel->getUsers();
     //print_r($data);

     // passing the array attribute $data to the view as a 2nd argument
     $this->load->view('users_list',$data);
   }

/*  public function index() {
    $this->load->view('form');
    $this->load->model('usermodel');
  }
  */

   public function read() {
     $this->load->model('usermodel');
     $this->usermodel->putUsers($_POST);
     //$this->load->model('usermodel');
     //$this->usermodel->putUsers($_POST);
   }

   public function update() {
     $this->load->model('usermodel');
     $this->usermodel->updateUsers();
   }

   public function delete() {
     $this->load->model('usermodel');
     $this->usermodel->deleteUsers();
   }

}
?>

<?php
//define('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller{

    function index() {
        // loading the view
        $this->load->view('form');

        // loading the Model Read
        $this->load->model('read');

        // loading function from the model
        $this->read->form_output();
    }

    // read data from View-Form
    function form_read() {
        $this->load->model('read');
        $this->read->insert_data($_POST);
    }
}
?>

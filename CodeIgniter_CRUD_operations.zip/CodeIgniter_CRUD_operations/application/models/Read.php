<?php
class Read extends CI_Model {
  function form_read() {
    echo "Hi";
  }

  function insert_data($data)
  {
    print_r($data);
  }
}
?>

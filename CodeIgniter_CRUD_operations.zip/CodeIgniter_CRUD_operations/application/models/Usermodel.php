<?php
class Usermodel extends CI_Model {

    public function getUsers() {

      // load the database
       $this->load->database();

      // then will be able to access database using the 'db' object
       $q  = $this->db->query("SELECT * FROM user_accounts");

       return $q->result();
      // printing the result object
      // print_r($q);

       /*return [
          ['firstname'=>'First User', 'lastname'=>'First Name'],
          ['firstname'=>'Second User', 'lastname'=>'Second Name'],
          ['firstname'=>'Third User', 'lastname'=>'Third Name'],
       ];  */
     }

     public function putUsers($res) {
       print_r($res);
       $this->db->insert('user_accounts', $res);
       echo "Record Inserted Successfully";
       //$this->load->database();
       //$this->db->insert('user_accounts', $res);
     }

     public function updateUsers() {
       $data = array(
               'firstname' => 'Agastya',
               'lastname' => 'Gundanna'
       );
       $this->db->where('id', '1');
       $this->db->update('user_accounts',$data);
       echo "Record Updated Successfully";
     }

     public function deleteUsers() {
       $this->db->where('firstname','Harsha');
       $res = $this->db->delete('user_accounts');
       print_r($res);
     }
}
?>

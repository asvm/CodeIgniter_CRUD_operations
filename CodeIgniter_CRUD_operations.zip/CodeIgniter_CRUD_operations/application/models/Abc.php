<?php

class Abc extends CI_Model {

    public function() {

    }	
}

<?php
class Fetch extends CI_Model {
	function model_read() {
		echo "This function is running from Model!";
	}
}

?>
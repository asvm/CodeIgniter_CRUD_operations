<?php

class Authenticate extends CI_Model {
   
   public function getData()
   {
     return ['abc'=>'ABC','xyz'=>'XYZ'];
   }
}

?>
